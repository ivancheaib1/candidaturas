<?php
if(!isset($_SESSION['usuario']) || $_SESSION['usuario']['nivel_acceso'] != 1){
    header("Location: login.php");
    die();
}
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Panel Administrativo</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>

    <div class="row">
        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-users me-1"></i>
                    Gestión de Usuarios
                </div>
                <div class="card-body">
                    <p>Administrar usuarios del sistema</p>
                    <a href="usuarios" class="btn btn-primary">Ir a Usuarios</a>
                </div>
            </div>
        </div>
    </div>
</div>
