<?php
require_once('ws/conexion.php');
require_once('ws/funciones.php');

$mesa = $_POST['mesa'];
$orden = $_POST['orden'];
$distrito = $_POST['distrito'];
$where = " where mesa = $mesa and orden = $orden and cod_dist = $distrito";

  $query = "SELECT 
		mesa,
		orden,
		voto_registrado
	FROM
	".$prefijo_tabla."padron".$where ;
	
	$resultados = select_sql($query);
	$result_json = $resultados["resultado"][0];
	
	if($result_json['mesa'] == $mesa and $result_json['orden'] == $orden){
		$query = "UPDATE  ".$prefijo_tabla."padron  SET	voto_registrado = 1".$where;		
		$resultados = ejecutar_sql($query);			
		if(!$resultados['error']){
		header("Location: http://".$_SERVER["SERVER_NAME"]."/".$carpeta_sistema."carga_datos.php?status=ok&mesa=".$mesa."&orden=".$orden);die();		
		}
		}else{
		header("Location: http://".$_SERVER["SERVER_NAME"]."/".$carpeta_sistema."carga_datos.php?status=no");die();	
		}
		  
?>