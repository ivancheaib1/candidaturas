<?php 
require_once('ws/conexion.php');
require_once('ws/funciones.php');

$url = explode("/", trim($_SERVER["REQUEST_URI"], '/'));
//var_dump($url);exit;
$pagina_solicitada = isset($url[0]) ? $url[0] : '';
$es_pagina_default = ($pagina_solicitada == "" or substr($pagina_solicitada,0,5) == "index");
$pagina = $es_pagina_default ? "inicio.php" : $pagina_solicitada.'.php';
unset($url[0]);unset($url[$posicion]);
$variables = array_values($url);

//echo $pagina; exit();

if(!isset($_SESSION['usuario']) and ($pagina != "inicio.php" or $pagina != "loginveedor.php")){
	header("Location: http://".$_SERVER["SERVER_NAME"]."/".$carpeta_sistema."login");die();
}
 //print_r($_SESSION);
 $nivel_acceso = $_SESSION['usuario']['nivel_acceso'];

// Solo redirigir si es la página por defecto
if($es_pagina_default){
	if($nivel_acceso == '1' ){
		$pagina = "usuarios.php";

	}
	if($nivel_acceso == '2' ){
		$pagina = "carga_datos.php";

	}
	if($nivel_acceso == '3' ){
		$pagina = "invitados.php";

	}
}

$query = "SELECT id,nombre,icono,logo imagen,correo,mapa,estado,facebook,whatsapp FROM ".$prefijo_tabla."sitio WHERE estado = 1 AND id = 1";
$empresa = $_SESSION['empresa'] = select_sql($query)["resultado"][0];
if($empresa["imagen"] == "" or  !file_exists("assets/img/".$empresa["imagen"])){
    $empresa["imagen"] = "logo.png";
} 

if($empresa["icono"] == "" or !file_exists("assets/img/".$empresa["icono"])){
    $empresa["icono"] = "ico.png";
} 
InsertarPeticion();


if(!file_exists($pagina)){http_response_code(404);$pagina = "404.php";} 

require_once('encabezado.php');
///require_once('menu.php'); 
//print_r($pagina);
//var_dump($_SESSION);
include($pagina);
require_once('pie.php');



mysqli_close($mysqli_web);

?> 