<?php
error_reporting(1);
if(!isset($_SESSION)){@session_start();}
date_default_timezone_set('America/Asuncion');

// =====================================================
// CONFIGURACIÓN PARA ENTORNO DOCKER (DESARROLLO LOCAL)
// =====================================================

// Detectar si estamos en Docker o en entorno normal
$en_docker = (getenv('DB_HOST') !== false) || (php_sapi_name() === 'cli' && file_exists('/.dockerenv'));

if ($en_docker) {
    // === CONFIGURACIÓN PARA DOCKER ===
    // Usando el usuario 'hcmisiones' que creaste y funciona
    $hostname_web = "host.docker.internal";
    $database_web = "hcmisiones";
    $username_web = "hcmisiones";
    $password_web = "123hcmisiones123//";
    $prefijo_tabla = "hc_";
    $puerto_web = 3310;
    
} else {
    // === CONFIGURACIÓN PARA ENTORNO NORMAL (SERVIDOR REAL) ===
    // Configuración original que usabas en producción
    $hostname_web = "localhost";
    $database_web = "sanbenje_hcmisiones";
    $username_web = "sanbenje_hcmisiones";
    $password_web = "123hcmisiones123//";
    $prefijo_tabla = "hc_";
    // No especificamos puerto para usar el default (3306)
}

// Construir la conexión con puerto incluido si es necesario
if (isset($puerto_web) && $puerto_web != '3306') {
    $mysqli_web = mysqli_connect($hostname_web, $username_web, $password_web, $database_web, $puerto_web);
} else {
    $mysqli_web = mysqli_connect($hostname_web, $username_web, $password_web, $database_web);
}

// Verificar conexión
if ($mysqli_web->connect_errno) { 
    $respuesta = "Fallo al conectar a Base de Datos MySQL: " . $hostname_web;
    if (isset($puerto_web)) $respuesta .= ":" . $puerto_web;
    $respuesta .= " (" . $mysqli_web->connect_errno . ") " . $mysqli_web->connect_error;
    
    // En desarrollo Docker, mostrar más detalles
    if ($en_docker) {
        $respuesta .= "<br><br><strong>Ayuda rápida:</strong><br>";
        $respuesta .= "1. Verifica que el contenedor MySQL esté corriendo: <code>docker ps | grep mysql</code><br>";
        $respuesta .= "2. Prueba desde el contenedor PHP: <code>docker exec -it candidaturas_php bash -c 'apt-get update && apt-get install -y mysql-client && mysql -h $hostname_web -P {$puerto_web} -u $username_web -p'</code>";
    }
    
    echo $respuesta;
    exit();
}

// Configuración de zona horaria para MySQL
$horaMysql = " DATE_ADD(now(), INTERVAL -6 HOUR) "; // Paraguay

// Establecer charset
mysqli_set_charset($mysqli_web, "utf8");

// Para debugging (muestra logs SQL)
$mostrarLogSQL = true; // imprime los querys en los json de la webservice

// Funciones auxiliares
function select_sql($sql_SELECT)
{
    $_SESSION['sql'][] = $sql_SELECT;
    $error = true;
    $consulta = $GLOBALS['mysqli_web']->query($sql_SELECT);
    $result_array = array();
    
    if ($consulta) {
        $result_array = $consulta->fetch_all(MYSQLI_ASSOC);
        $error = false;
    } else {
        $error = true;
        $result_array = $GLOBALS['mysqli_web']->error;
    }
    return array("error" => $error, "resultado" => $result_array);
}

function ejecutar_sql($sql_ejecutar)
{
    $_SESSION['sql'][] = $sql_ejecutar;
    $error = true;
    $result = null;
    
    if ($GLOBALS['mysqli_web']->query($sql_ejecutar)) {
        $result = $GLOBALS['mysqli_web']->insert_id;
        $error = false;
    } else {
        $result = $GLOBALS['mysqli_web']->error;
        $error = true;
    }
    
    return array("error" => $error, "resultado" => $result);
}
?>